import random
import game
import sys
import numpy as np

# Constants
UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3

def find_best_move(board):
    best_move = None
    best_score = float('-inf')

    for move in [UP, DOWN, LEFT, RIGHT]:
        newboard = execute_move(move, board)

        # If the move is not valid (i.e. the board does not change), skip it
        if board_equals(board, newboard):
            continue

        score = heuristic_score(newboard)

        if score > best_score:
            best_score = score
            best_move = move

    # In the rare case no valid move is found, choose a random one (shouldn't occur)
    if best_move is None:
        return find_best_move_random_agent()

    return best_move

def find_best_move_random_agent():
    return random.choice([UP, DOWN, LEFT, RIGHT])

def execute_move(move, board):
    if move == UP:
        return game.merge_up(board)
    elif move == DOWN:
        return game.merge_down(board)
    elif move == LEFT:
        return game.merge_left(board)
    elif move == RIGHT:
        return game.merge_right(board)
    else:
        sys.exit("No valid move")

def board_equals(board, newboard):
    """
    Check if two boards are equal
    """
    return (newboard == board).all()

def heuristic_score(board):
    # 1. Priority: Keep the largest tile in the top-left corner
    corner_weight = board[0, 0] * 4

    # 2. Priority: Keep cells around the largest tile non-zero
    cells_around_corner_weight = -np.sum(board[0:2, 0:2] == 0) * 10

    # 3. Priority: Count the number of merges (non-zero cells)
    merge_count_weight = np.sum(board > 0) * 3

    # 4. Priority: For a more advanced version, you can consider the monotonicity
    #    of the rows and columns. It's not covered here for simplicity.

    return corner_weight + cells_around_corner_weight + merge_count_weight
